Theme Name: Gram
Theme URI: http://theme.sir.kr/gnuboard54/demo/gram
Maker: SIR
Maker URI: http://sir.kr
Version: 5.4.2.7
Detail: GRAM 테마는  SIR에서 제공하는 그누보드5.4 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html