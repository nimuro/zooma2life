Theme Name: 퓨어블루 5.5
Theme URI: http://theme.sir.kr/youngcart54/demo/pureblue54
Maker: SIR
Maker URI: http://sir.kr
Version: 5.5.8
Detail: 퓨어블루 테마는  SIR에서 제공하는 그누보드5.5 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html